/**
 * Created by Comp1 on 1/13/2017.
 */
$(function(){
    // $(".dropdown").hover(
    //     function() {
    //         $('.dropdown-menu', this).stop( true, true ).fadeIn("fast");
    //         $(this).toggleClass('open');
    //         $('b', this).toggleClass("caret caret-up");
    //     },
    //     function() {
    //         $('.dropdown-menu', this).stop( true, true ).fadeOut("fast");
    //         $(this).toggleClass('open');
    //         $('b', this).toggleClass("caret caret-up");
    //     });
    $('#cp2').colorpicker();
});
