<div class="settings_for_footer_12">

    <div class="form-group my_rows1">
        <label class="col-md-4 control-label" for="new_widget_1">Footer Widget - 1</label>
        <div class="col-md-8">
            {!! BBbutton('widgets','new_widget_1','Select The Widget',['class'=>'form-control','data-type'=>'others']) !!}
        </div>
    </div>

    <div class="form-group my_rows1">
        <label class="col-md-4 control-label" for="new_widget_3">Footer Widget - 2</label>
        <div class="col-md-8">
            {!! BBbutton('widgets','new_widget_2','Select The Widget',['class'=>'form-control','data-type'=>'others']) !!}
        </div>
    </div>

    <div class="form-group my_rows1">
        <label class="col-md-4 control-label" for="new_widget_3">Footer Widget - 3</label>
        <div class="col-md-8">
            {!! BBbutton('widgets','new_widget_3','Select The Widget',['class'=>'form-control','data-type'=>'others']) !!}
        </div>
    </div>

    <div class="form-group my_rows1">
        <label for="footerstyle_12" class="col-sm-4 labelTitle">Footer style</label>
        <div class="col-sm-8">
            {!! BBbutton('styles','footerstyle_12','Select Footer Style',['class'=>'form-control input-md','data-type'=>'container']) !!}
        </div>
    </div>

</div>