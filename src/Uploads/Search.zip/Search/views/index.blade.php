@extends('layouts.admin')

@section('content')

@stop
@section('CSS')
@stop
@section('JS')
@stop